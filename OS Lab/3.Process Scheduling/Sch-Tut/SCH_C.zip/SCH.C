#include<stdio.h>
#include<conio.h>
typedef struct sys
{
	int bt,at,flag,proc,count,eq;
}
sys;
sys t1[10];
int qu[100],r=0,f=0;
int n;
void input();
void output();
void sort(sys s1[],int);
void fcfs();
void sjfp();
void sjfnp();
void rr();
void insert(int,struct sys p[]);
int extract();
void main()
{
	int ch;
	clrscr();
	do
	{
		clrscr();
		printf("\n\n-------MENU-------");
		printf("\n 1. First Come First Serve(FCFS)");
		printf("\n 2. Shortest Path First-Preempitve(SJF[p])");
		printf("\n 3. Shortest Path First-NonPreempitve(SJF[np])");
		printf("\n 4. Round Robin (RR)");
		printf("\n 5. Exit");
		printf("\n---------------------");
		printf("\nEnter your choice:");
		scanf("%d",&ch);
		switch(ch)
		{
			case 1:input();fcfs();break;
			case 2:input();sjfp();break;
			case 3:input();sjfnp();break;
			case 4:input();rr();break;
			case 5:exit(0);
			default:printf("\n Wrong Choice Entered..");break;
		}
	}while(ch!=5);
	getch();
}
void input()
{
	int i,j;
	sys temp;
	printf("\n enter the no. of processes:");
	scanf("%d",&n);
	printf("\n enter the arrival time & cpu burst time for process");
	for(i=0;i<n;i++)
	{
		printf("\n for process no. %d)",i+1);
		t1[i].proc=i+1;
		printf("enter arrival time:");
		scanf("%d",&t1[i].at);
		printf("Enter burst time:");
		scanf("%d",&t1[i].bt);
		t1[i].flag=0;
	}
	for(i=0;i<n;i++)
		for(j=0;j<n;j++)
			if(t1[i].at<t1[j].at)
			{
				temp=t1[i];
				t1[i]=t1[j];
				t1[j]=temp;
			}
	printf("\n\n=----");
	getch();
}

void output()
{
	int i;
	printf("\n Process \tBurst time\tArrival.time");
	for(i=0;i<n;i++)
	{
		printf("\n p%d",t1[i].proc);
		printf("\t\t%d",t1[i].bt);
		printf("\t\t%d",t1[i].at);
	}
}

void sort(struct sys s1[],int k)
{
	sys temp;
	int i,j;
	for(i=1;i<k;i++)
	for(j=0;j<i;j++)
	if(s1[i].bt<s1[j].bt)
	{
		temp=s1[i];
		s1[i]=s1[j];
		s1[j]=temp;
	}
}
void fcfs()
{
	int i,j,k=0,st,et=0,min,ch,sta[10],eta[10];
	float avt=0,tat=0;
	for(i=0;i<n;i++)
	t1[i].flag=0;
	output();
	printf("\n\n Process \tprocess time");
	for(k=0;k<n;k++)
	{
		min=999;
		for(i=0;i<n;i++)
		if(t1[i].at<min && t1[i].flag==0)
		{
			min=t1[i].at;
			j=i;
		}
		t1[j].flag=1;
		printf("\n P%d",t1[j].proc);
		st=et;
		sta[k]=et-t1[j].at;
		et=et+t1[j].bt;
		eta[k]=et-t1[j].at;
		printf("\t\t%d-%d",st,et);
	}
	for(i=0;i<n;i++)
	{
		avt=avt+sta[i];
		tat=tat+eta[i];
	}
	avt=avt/n;
	tat=tat/n;
	printf("\n\nAverage waiting time:%f\n Average Turnaround time: %f",avt,tat);
	printf("\n------------------------------------------------------------------");
	getch();
}


void sjfp()
{
	int i,j,k=0,min,min1,q,tot=0,temp;
	int sta[10],eta[10];
	float avt=0,tat=0;
	sys t[10];
	for(i=0;i<n;i++)
	{
		t[i].at =t1[i].at;
		t[i].bt =t1[i].bt;
		t[i].flag=t1[i].flag=0;
		tot=tot+t[i].bt;
	}
	output();
	printf("\n\n process\t process time");
	while(k<tot)
	{
		min1=999;
		min=k;
		for(i=0;i<n;i++)
		if(t[i].at<min&&t[i].bt<=min1&&t[i].flag==0)
		{
			if(t[i].bt==min1)
			{
				if(t[i].at<t[j].at)
				{
					j=i;
					min1=t[i].bt;
					}
				}
				else
				{
					min1=t[i].bt;
					j=i;
				}
			}
			printf("\n p%d",t1[j].proc);
			printf("\t\t%d-%d",k,k+1);
			k++;
			t[j].bt=t[j].bt-1;
			if(t[j].bt<=0)
			{
				eta[j]=k-t[j].at;
				t[j].flag=1;
			}
	}
	for(i=0;i<n;i++)
	{
		sta[i]=eta[i]-t1[i].bt;
		avt=avt+sta[i];
		tat=tat+eta[i];
	}
	avt=avt/n;
	tat=tat/n;
	printf("\n\n average waiting time:%f\n average turnaround time%f",avt,tat);
	printf("\n------------------------");
	getch();
}




void sjfnp()
{
	int i,j,k=0,st,et=0,min,min1,ch,sta[10],eta[10];
	sys s1[20];
	float avt=0,tat=0;
	for(i=0;i<n;i++)
	t1[i].flag=0;
	output();
	printf("\n\n process \t process time");
	sta[0]=t1[0].at;
	eta[0]=t1[0].bt+t1[0].at;
	et=eta[0];
	printf("\n%d",t1[0].proc);
	printf("\t\t %d-%d",sta[0],eta[0]);
	for(k=1;k<n;k++)
	{
		for(i=1,j=0;j<n&&t1[i].at<=et;i++)
		if(t1[i].flag==0)
		s1[j++]=t1[i];
		sort(s1,j);
		for(i=0;i<n;i++)
		if(s1[0].proc==t1[i].proc&&t1[i].flag==0)
		{
			j=i;
			goto a;
		}
		a:t1[j].flag=1;
		printf("\n p %d",t1[i].proc);
		st=et;
		sta[k]=st-t1[j].at;
		et=et+t1[i].bt;
		eta[k]=et-t1[i].at;
		printf("\t\t %d-%d",st,et);
	}
	for(i=0;i<n;i++)
	{
		avt=avt+sta[i];
		tat=tat+eta[i];
	}
	avt=avt/n;
	tat=tat/n;
	printf("\n\nAverage waiting time:%f\nAverage turnaround time:%f",avt,tat);
	printf("\n-------------------------------------------------------------");
	getch();
}



void rr()
{
	int st=0,et=0,flag=0,turn_around_time[20]={0},tt1_turn_around_time;
	int no,tq,k,i,total=0,total_turn_around_time=0,wait_time=0;
	float avg_turn_around_time,avg_wait_time;
	clrscr();
	for(i=0;i<n;i++)
	{
		total=total+t1[i].bt ;
	}
	output();
	printf("\n\n Enter time quantam:");
	scanf("%d",&tq);
	for(i=0;i<100;i++)
	{
		qu[i]=-1;
	}
	for(i=0;i<n;i++)
	{
		if(t1[i].at<=et && t1[i].bt!=0 && t1[i].flag!=1)
		{
			insert(i,t1);
			t1[k].flag=0;
		}
	}
	printf("\n\n process \tprocess time");
	while(flag==0)
	{
		k=extract();
		t1[k].flag=0;
		st=et;
		if(t1[k].bt>tq)
		{
			t1[k].bt=t1[k].bt=t1[k].bt-tq;
			et+=tq;
		}
		else
		{
			et=et+t1[k].bt;
			t1[k].bt=0;
			turn_around_time[k]=et-t1[k].at;
		}
		printf("\n p%d",t1[k].proc);
		printf("\t\t %d-%d",st,et);
		for(i=0;i<n;i++)
		{
			if(t1[i].at<=et && i!=k && t1[i].flag!=1 && t1[i].bt!=0)
			{
				insert(i,t1);
				t1[i].flag=1;
			}
		}
		if(t1[k].bt!=0)
		{
			insert(k,t1);
			t1[k].flag=1;
		}
		flag=1;
		for(i=0;i<n;i++)
		{
			if(t1[i].bt!=0)
			flag=0;
		}
	}
	k=0;
	for(i=0;i<n;i++)
	{
		total_turn_around_time=total_turn_around_time+turn_around_time[k];
		k++;
	}
	avg_turn_around_time=(float)total_turn_around_time/n;
	wait_time=total_turn_around_time-total;
	avg_wait_time=(float)wait_time/n;
	printf("\n\n Average waiting time=%f",avg_turn_around_time);
	printf("\n\n Average turn around time=%f",avg_wait_time);
	printf("\n-----------------------------------------------------------");
	getch();
}
//-----------------------------------------------------------
int front=0,rear=0;

//----------------------------------------------------


void insert(int val,struct sys p[])
{
	int i,j;
		qu[rear]=val;
	rear++;
}

//-----------------------------------------------------
int extract()
{
	int val,i,j;
	val=qu[front];
	for(i=0,j=1;i<rear;i++,j++)
		qu[i]=qu[j];
	rear--;
	return(val);
}


/*-------------------------------->>END<<---------------------------*/